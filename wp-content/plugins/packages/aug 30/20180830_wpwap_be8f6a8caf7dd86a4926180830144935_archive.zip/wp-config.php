<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'sigma-wpwad');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '4P1)jho`vPlN/7tZ//;L+4*?s&i,g=E7Z:=`ikC_c}[LQ91:r~-JKo[D1);:,(sW');
define('SECURE_AUTH_KEY',  ',-~W~803r|VA4,2cr+Yp@`w#t[w]HM?o7b1_eWo.#DPB7WFnzAv(Vo`eS|m-Qg8%');
define('LOGGED_IN_KEY',    '~aE(B2m6}93#WNLt$B;gmnNo[`)$,vG.;_,1xfb|CtD+EiCkyrpa/lkw^0+Byh4=');
define('NONCE_KEY',        'yp*M-aQ+o` GG08Y^NZ?gsKs4R3gaYAGue;S`$mad(&3eJ%<Vir/u Za`fp_@7(e');
define('AUTH_SALT',        'eRuEW@=4Tm&(mQI(&kEz=#<(-B)]b8+U:^8dL, sVdw_pHJ(.mO{%-#11D|VXS#9');
define('SECURE_AUTH_SALT', 't95+PzwnIa4gqYd~_ }Q$(pV8+fF&#(^2x//t/tm=[znMR[t_ceKP6gC#&ym;Vh^');
define('LOGGED_IN_SALT',   'H` ]:4Cl#D->L7.+#AJDzBZFmkL j :dQEA:,d`~N?gI75P yb5){VW5TV!MEUV[');
define('NONCE_SALT',       'Nt-ZvI>v0dXE;hUA)SLClCt#NR#uIe]FC6-6p;|,oQ)e$({sE#aFe#|yoK.AK~$r');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
